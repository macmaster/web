// index.js
// Content Pallette for the Cluster Dashboard.

import Repositories from './repositories';

import React from 'react';
import { withStyles } from '@material-ui/core/styles'

const styles = theme => ({
  root: {
    textAlign: "center",
    color: "red",
  }
});

class Content extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { classes, title } = this.props;
    const accessToken = this.props.accessToken ||
      "34ae28b46c779e77f264441dab2d56b85ab45994";

    return (
      <div className={classes.root}>
        <h1>{title}</h1>
        <Repositories request={{
          api: "https://bbgithub.dev.bloomberg.com/api/v3",
          user: "BACH-Clusters",
          accessToken: accessToken,
        }} />
      </div>
    );
  }
}

export default withStyles(styles)(Content);

// index.js
// Application entry point.

import Content from './content'

import React, { Component } from 'react';
import ReactDOM from 'react-dom';


var content = ReactDOM.render(
  <Content title='I love nature!' />,
  document.getElementById('content')
);


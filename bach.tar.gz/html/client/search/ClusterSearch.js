// ClusterSearch.js
// Data Model for the BACH GitHub Repositories.

import SearchBar from 'search/SearchBar';

import React from 'react';
import { withStyles } from '@material-ui/core/styles'

const styles = theme => ({ });

class ClusterSearch extends React.Component {
  constructor(props) {
    super(props);

    // Fetch the Github Repositories
    this.sendGithubRequest(this.props.request);

    this.state = {
      repositories: [],
    };
  }

  sendGithubRequest(request) { 
    const params = Object.entries({
      per_page: 100,
      access_token: request.accessToken,
    }).map(([key, value]) =>
      key + "=" + value
    ).join("&");

    const requestURL = 
      request.api +
      "/users/" + request.user +
      "/repos?" + params;

    // console.log("Repositories Request: " + requestURL);
    this.requestURL = requestURL;

    // Perform an HTTP GET request
    fetch(requestURL).then(response =>
      response.json()
    ).then(json =>
      this.processGithubResponse(json)
    ).catch(error =>
      console.error(error)
    );
  }

  processGithubResponse(response) {
    const repositories = response;
    repositories.forEach(repo => console.log(repo));
    this.setState({ repositories });
  }

  render() {
    return (
      <SearchBar className={this.props.className} 
        repositories={this.state.repositories} />
    );
  }
}

export default withStyles(styles)(ClusterSearch);

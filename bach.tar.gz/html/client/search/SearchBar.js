// SearchBar.js
// Search Bar for repositories

import React from 'react';
import { withStyles } from '@material-ui/core/styles'
import { Link, history } from 'react-router-dom';

import AutoSuggest from 'react-autosuggest';

const styles = theme => ({
  root: {
    width: "100%",
  },

  container: {
    position: "relative",
  },
  input: {
    width: "100%",
    fontSize: "300%",
    border: "1px solid #aaa",
    padding: "15px",
    borderRadius: "3px",
    boxSizing: "border-box",
  },
  suggestionsContainerOpen: {
    display: "block",
    width: "100%",
    maxHeight: "35vh",
    overflowY: "auto",
    fontSize: "100%",
    border: "1px solid #aaa",
    borderRadius: "3px",
    backgroundColor: "#fff",
    zIndex: "2",
    position: "absolute",
  },
  suggestionsList: {
    margin: "0",
    padding: "0",
    listStyleType: "none",
  },
  suggestion: {
    cursor: "pointer",
    padding: "10px",
    border: "1px solid #aaa",
  },
  suggestionHighlighted: {
    backgroundColor: "#ddd",
    color: "red",
  },
});

class SearchBar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      value: '',
      suggestions: [],
    };

    this.onChange = (event, { newValue }) => {
      this.setState({
        value: newValue
      });
    }
  }

  getSuggestions(value) {
    const { repositories } = this.props;
    value = value.trim().replace(
      /[.*+?^${}()|[\]\\]/g, '\\$&'
    );

    const regex = new RegExp(`^${value}`, 'i');
    return repositories.filter(repo => regex.test(repo.name));
  }

  getSuggestionValue(suggestion) {
    console.log("getSuggestionValue(): " + suggestion);
    return suggestion.name;
  }

  fetchSuggestions({ value }) {
    this.setState({
      suggestions: this.getSuggestions(value)
    });
  }

  clearSuggestions() {
    this.setState({
      suggestions: []
    });
  }

  suggestionSelected(event, { suggestion, suggestionValue }) {
    location.href = "/cluster?name=" + suggestionValue;
  }

  renderSuggestion(suggestion) {
    return (
      <Link to={{ 
        pathname: "/cluster",
        search: '?name=' +
          this.getSuggestionValue(suggestion)
      }}>
        {suggestion.name.toUpperCase()}
      </Link>
    );
  }

  render() {
    const { classes, repositories } = this.props; 
    const { value, suggestions } = this.state;

    let options = repositories.map(repo => {
      let name = repo.name.toUpperCase();
      if (/^P/.test(name)) {
        repo.category = "PROD";
      } else if (/^D/.test(name)) {
        repo.category = "DEV";
      } else if (/^B/.test(name)) {
        repo.category = "BETA";
      } else {
        repo.category = "MISC";
      }
      return repo;
    });

    const inputProps = {
      placeholder: "cluster...",
      value: value,
      onChange: this.onChange,
      autoFocus: true,
      name: "name",
    };

    return (
      <div className={classes.root}>
        <form action="/cluster">
          <AutoSuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={this.fetchSuggestions.bind(this)}
            onSuggestionsClearRequested={this.clearSuggestions.bind(this)}
            onSuggestionSelected={this.suggestionSelected.bind(this)}
            getSuggestionValue={this.getSuggestionValue.bind(this)}
            renderSuggestion={this.renderSuggestion.bind(this)}
            inputProps={inputProps}
            theme={classes}
          />
        </form>
      </div>
    );
  }
}

export default withStyles(styles)(SearchBar);

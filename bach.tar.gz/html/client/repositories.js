// repos.js
// Data Model for the BACH GitHub Repositories.

import React from 'react';
import { withStyles } from '@material-ui/core/styles'

const styles = theme => ({
  root: {
    textAlign: "center",
    color: "red",
  }
});

class Repositories extends React.Component {
  constructor(props) {
    super(props);

    // Fetch the Github Repositories
    this.sendGithubRequest(this.props.request);

    this.state = {
      repositories: {},
    };
  }

  sendGithubRequest(request) { 
    const params = Object.entries({
      per_page: 100,
      access_token: request.accessToken,
    }).map(([key, value]) =>
      key + "=" + value
    ).join("&");

    const requestURL = 
      request.api +
      "/users/" + request.user +
      "/repos?" + params;
    
    console.log("Repositories Request: " + requestURL);

    // Perform an HTTP GET request
    fetch(requestURL).then(response =>
      response.json()
    ).then(json =>
      this.processGithubResponse(json)
    ).catch(error =>
      console.error(error)
    );
  }

  processGithubResponse(response) {
    const repositories = response.json();
    this.setState({ repositories });
    console.log("repositories: " + repositories);
  }

  render() {
    const { classes } = this.props; 

    return (
      <div className={classes.root}>
        <p>{this.requestURL}</p>
      </div>
    );
  }
}

export default withStyles(styles)(Repositories);

// Content.js
// Content Pallette for the Cluster Dashboard.
// Manages the routes with a react router.

import Search from 'content/Search';
import Cluster from 'content/Cluster';

import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';

export default class Content extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const search = () => (
      <Search title="BACH Cluster Dashboard" />
    );

    const cluster = (props) => {
      console.log("query:", props);
      return <Cluster message={props.location.search} />
    };

    const error = () => (
      <p>ERROR: 404</p>
    );

    return (
      <BrowserRouter>
        <div>
          <Route exact path='/' component={search} />
          <Route path='/cluster' component={cluster} />
        </div>
      </BrowserRouter>
    );
  }
}

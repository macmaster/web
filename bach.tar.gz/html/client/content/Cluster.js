// Cluster.js
// Content Pallette for the Cluster Route.

import Nature from 'background/Nature';

import React from 'react';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({ });

class Cluster extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { classes } = this.props;
    return (
      <div className={classes.root}>
        <Nature />
        <p>{this.props.message}</p>
      </div>
    );
  }
}

export default withStyles(styles)(Cluster);

// Search.js
// Content Pallette for the Search Route.

import ClusterSearch from 'search/ClusterSearch';
import Sunset from 'background/Sunset';

import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';

const styles = theme => ({
  root: {
    display: "block",
    margin: "auto",
    width: "50%",
  },

  flex: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignContent: "center",
    height: "100vh",
  },
  title: {
    color: "white",
    fontSize: "4rem",
    textAlign: "center",
    margin: "10px",
  }
});

class Search extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const { classes, title } = this.props;
    const request = {
      api: this.props.api ||
        "https://api.github.com",
      user: this.props.user ||
        "ronny-macmaster",
      accessToken: this.props.accessToken ||
        "667747ab5d3169ed3c080ab4ff9301c10a40db8d",
    };

    return (
      <div className={classes.root}>
        <Sunset />
        <div className={classes.flex}>
          <Typography className={classes.title}
            variant="title">{title}</Typography>
          <ClusterSearch request={request} />
        </div>
      </div>
    );
  }
}

export default withStyles(styles)(Search);

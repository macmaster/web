// Register.js
// Content pallete for the /register route.

import React from 'react';
import { Redirect, Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import {
  Typography,
} from '@material-ui/core';

class Register extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      // TODO
    };
  }

  render() {
    const {
      classes,
      title,
    } = this.props;

    return (
      <div className={classes.root}>
        <Typography variant="display1">Register</Typography>
        <p>Welcome to the BACH Portal.</p>
      </div>
    );
  }
}

const styles = theme => ({
  root: { }
});

export default withStyles(styles)(Register);

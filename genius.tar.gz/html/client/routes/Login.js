// Login.js
// Content pallette for the /login route.

import React from 'react';
import { Redirect, Link } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';
import { 
  Button,
  LinearProgress,
  Paper, 
  TextField,
  Typography,
} from '@material-ui/core';

class Login extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      redirect: props.cookie,

      // fields
      name: null,
      password: null,

      error: null,
      errors: {
        name: false,
        password: false,
      }
    };
  }

  render() {
    const { 
      classes,
      action,
      title,
    } = this.props;

    if (this.state.redirect) {
      return <Redirect exact push to="/dashboard" />;
    } else {
      console.log("redirect: ", this.state.redirect);
    }

    let errorMessage = this.state.error && (
      <Typography className={classes.error}>
        {this.state.error}
      </Typography>
    );

    let progress = this.state.loading && (
      <LinearProgress className={classes.progress} />
    );

    return (
      <div className={classes.root}>
        <div className={classes.flex}>

          <Paper className={classes.paper}>
            {progress}
            <form action={action} className={classes.form}>
              <Typography variant="display1" align="center">
                {title}</Typography>
              <TextField name="username" placeholder="username" 
                required error={this.state.errors.name} autoFocus
                className={classes.input} onChange={e => this.onChange(e)} />
              <TextField name="password" placeholder="password"
                required error={this.state.errors.password} type="password"
                className={classes.input} onChange={e => this.onChange(e)} />
              <Button color="primary" variant="raised" type="submit"
                className={classes.submit} onClick={e => this.onSubmit(e)}>
                Login</Button>
              <Link to="/register">
                <Button color="secondary" variant="raised"
                  className={classes.submit}>
                  Register</Button>
              </Link>
              {errorMessage}
            </form>
          </Paper>

        </div>
      </div>
    );
  }

  onSubmit(e) {
    e.preventDefault();
    this.setState({loading: true});
    this.validate();
  }

  onChange(e) {
    this.setState({[e.target.name]: e.target.value});
  }

  validate() {
    setTimeout(() => {
      this.setState({loading: false});
      if (this.login(this.state.name, this.state.password)) {
        console.log("state: ", this.state);
        localStorage.setItem("name", this.state.name);
        localStorage.setItem("cookie", this.state.password);
        this.props.setCookie(localStorage.getItem("cookie"));
        this.setState({redirect: true});
      } else {
        let reducer = (acc, curr) => Object.assign(acc, { [curr]: true });
        let error = "Wrong password, try again or click register to sign up.";
        let errors = Object.keys(this.state.errors).reduce(reducer, {});
        console.log("errors:", errors);
        this.setState({error, errors});
      }
    }, 500);
  }

  login(name, password) {
    // TODO: Authenticate with Web Service.
    const passwords = {
      rmacmaster: "Physics17",
      aanand59: "password",
      rali43: "password",
      acpi: "naruto1",
    };
    return (password === passwords[name]);
  }

}

const styles = theme => ({
  root: {
    display: "block",
    margin: "auto",
  },

  flex: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignContent: "center",
    height: "100vh",
    textAlign: "center",
  },

  paper: {
    margin: "auto",
    width: "100%",
    height: "100%",
    maxWidth: "400px", 
    maxHeight: "400px", 
  },

  form: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    width: "100%",
    height: "100%",
  },

  input: {
    margin: "10px",
    width: "80%",
    margin: "10px auto",
  },

  submit: {
    width: "80%",
    margin: "15px auto",
  },

  progress: {
    borderRadius: "5px",
    opacity: "0.5",
  },

  error: {
    color: "red",
  },
});

export default withStyles(styles)(Login);

// Hadoopy.js
// Hadoopy Background Image.

import React from 'react';
import { withStyles } from '@material-ui/core/styles'

const styles = theme => ({
  root: {
    position: "absolute",
    top: "0",
    left: "0",
    zIndex: "-999999",
    width: "100%",
    height: "100%",
  },
  hadoopy: {
    position: "fixed",
    bottom: "0px",
    right: "20px",
    opacity: "0.5",
    width: "400px",
    zIndex: "-1",
  },
});

function Hadoopy(props) {
  return (
    <div className={props.classes.root}>
      <img className={props.classes.hadoopy} src="/images/hadoopy.png" />
    </div>
  );
}

export default withStyles(styles)(Hadoopy);


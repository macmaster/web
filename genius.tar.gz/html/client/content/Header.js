// Header.js
// Site header for the content pallete.

import React from 'react';
import { withStyles } from '@material-ui/core/styles';
import {
  AppBar,
  Button,
  Toolbar,
  Typography,
} from '@material-ui/core';

class Header extends React.Component {
  render() {
    const {
      classes,
      title,
      cookie,
    } = this.props;

    console.log("header_cookie: ", cookie);

    let logout = cookie && (
      <Button color="secondary" variant="raised"
        onClick={() => this.props.setCookie(null)}>
        Logout</Button>
    );

    return (
      <AppBar>
        <Toolbar className={classes.root}>
          <Typography className={classes.title}
            variant="title" color="inherit">
            {title}</Typography>
          {logout}
        </Toolbar>
      </AppBar>
    );
  }
}

const styles = theme => ({
  root: {
    display: "flex",
  },
  title: {
    flex: "auto",
  },
});

export default withStyles(styles)(Header);

// Content.js
// Content Pallette for the Genius Dashboard.
// Manages the routes with a react router.

// widgets
import Header from 'content/Header';

// backgrounds
import Hadoopy from 'background/Hadoopy';

// routes
import Login from 'routes/Login';
import Register from 'routes/Register';
import Dashboard from 'routes/Dashboard';

import React from 'react';
import { HashRouter, Route, Redirect, Switch } from 'react-router-dom';
import { withStyles } from '@material-ui/core/styles';

class Content extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      cookie: this.authenticate(),
    };
  }

  render() {
    const {
      classes,
      config = {
        title: "Genius",
        service: "http://dob2-bach-r4n01.bloomberg.com:9000",
      },
    } = this.props;

    // Check if user logged in.
    let redirect = null;
    if (!this.authenticate()) {
      redirect = <Redirect to="/login" />;
    } else {
      redirect = <Redirect exact from="/" to="/dashboard" />;
    }

    let header = (
      <Header title={config.title}
        cookie={this.state.cookie}
        setCookie={this.setCookie.bind(this)} />
    );

    const LoginRoute = props => (
      <Login {...props}
        action={`${config.service}/signin`} 
        title={config.title}
        cookie={this.state.cookie}
        setCookie={this.setCookie.bind(this)}
      />
    );

    const DashboardRoute = props => (
      <Dashboard {...props}
        title={config.title} />
    );

    const RegisterRoute = props => (
      <Register {...props}
        title={config.title} />
    );

    return (
      <div className={classes.root}>
        {header} <Hadoopy />
        <div className={classes.body}>
          <HashRouter>
            <Switch>
              <Route exact path='/login' render={LoginRoute} />
              <Route exact path='/register' render={RegisterRoute} />
              {redirect} // redirect unauthenticated sessions
              <Route exact path='/dashboard' render={DashboardRoute} />
            </Switch>
          </HashRouter>
        </div>
      </div>
    );
  }

  authenticate() {
    console.log("cookie: " + localStorage.getItem("cookie"));
    return localStorage.getItem("cookie");
  }

  setCookie(cookie) {
    this.setState({ cookie });
    if (cookie == null) {
      localStorage.removeItem("name");
      localStorage.removeItem("cookie");
    }
  }

}

const styles = theme => ({
  body: {
    paddingTop: "70px",
    overflow: "hidden",
  },
});

export default withStyles(styles)(Content);

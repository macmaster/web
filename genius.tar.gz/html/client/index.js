// index.js
// Application entry point.

import Content from 'content/Content'

import React, { Component } from 'react';
import ReactDOM from 'react-dom';

var content = ReactDOM.render(
  <Content />,
  document.getElementById('content')
);

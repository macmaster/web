var allClusterInfo = null;
var rolesregex = /role\[(.+)\]/;
var reciperegex = /recipe\[(.+)\]/;
var decommissionedregex = /DECOMMISSION/i;
var addevregex = /addev/i;
var adprdregex = /adprd/i;

var username = "BACH-Clusters";
var baseUrl = "https://bbgithub.dev.bloomberg.com/api/v3/";
var limitRepos = -1;
var selectedRepos = [];

var formAccessUrl = function(currentUrl) {
  var accessString = "34ae28b46c779e77f264441dab2d56b85ab45994";
  // TODO: if we have more than 100 repos, need to go to the next page
  return (currentUrl + "?per_page=100&access_token=" + accessString);
}

var formAccessUrlWithCallback = function(currentUrl) {
  return (formAccessUrl(currentUrl) + "&callback=?");
}

var parseClusterFile = function(data, repo) {
  if (data.data.content && data.data.encoding === "base64") {
    // var singleClusterInfo = window.atob( data.data.content.replace( /\n/g, "\n" ) );
    var singleClusterInfo = window.atob(data.data.content);
    //console.log( "ClusterData[" + singleClusterInfo + "]" );

    // var screen = $('<dl>');

    console.log("Repo[" + repo + "]");
    $(singleClusterInfo.split("\n")).each(function() {
      if (!this || this == "") {
        return false;
      }
      var parts = this.split(/\s+/);
      //console.log( "Parts[" + parts + "]" );
      var machines = allClusterInfo[repo]["machines"];

      //
      // Older files will have 7 fields, newer files have 8.
      // 'oo' is the offset for counting fields.
      //
      var oo = parts.length > 7 ? 1 : 0;
      //console.log("Offset: " + oo + ", parts.length: " + parts.length );

      machines[parts[oo + 0]] = new Object();
      var currentMachine = machines[parts[oo + 0]];
      currentMachine["machinename"] = parts[oo + 0];
      currentMachine["macaddress"] = parts[oo + 1];
      currentMachine["ipaddress"] = parts[oo + 2];
      currentMachine["roles"] = [];
      currentMachine["recipes"] = [];
      currentMachine["others"] = [];
      var rolesrecipes = parts[oo + 6].split(","); // Array with roles and
      //console.log( "ROLESRECIPES: " + rolesrecipes );
      for (idx = 0; idx < rolesrecipes.length; ++idx) {
        var match = rolesregex.exec(rolesrecipes[idx]);
        if (match && match[1]) // First element in matched is the
          // entire element matched by the regex
        {
          var roleValue = match[1].trim();
          currentMachine["roles"].push(roleValue);

          if (!allClusterInfo[repo]["urls"]) {
            allClusterInfo[repo]["urls"] = new Object();
          }
          var repoUrls = allClusterInfo[repo]["urls"];
          var urlBaseString = "http://" + currentMachine["machinename"] + ".hadoop.bloomberg.com:";
          var nonHadoopUrlBaseString = "http://" + currentMachine["machinename"] + ".bloomberg.com:";
          var thriftBaseString = "thrift://" + currentMachine["machinename"] + ".bloomberg.com:";
          var jdbcBaseString = "jdbc:hive2://" + currentMachine["machinename"] + ".bloomberg.com:";
          if (roleValue == "BCPC-Hadoop-Head-MapReduce") {
            repoUrls["Resource Manager Job History"] = urlBaseString + "19888";
            repoUrls["Oozie (CORP)"] = urlBaseString + "11000/oozie";
          }
          if (roleValue == "BCPC-Hadoop-Head-HBase") {
            repoUrls["HBase UI - (" + currentMachine["machinename"] + ")"] = urlBaseString + "16010";
          }
          if (roleValue == "BCPC-Hadoop-Head-ResourceManager") {
            repoUrls["YARN ResourceManager - (" + currentMachine["machinename"] + ")"] = urlBaseString + "8088";
          }
          if ((roleValue == "BCPC-Hadoop-Head-Namenode") || (roleValue == "BCPC-Hadoop-Head-Namenode-Standby")) {
            repoUrls["HDFS NameNode - (" + currentMachine["machinename"] + ")"] = urlBaseString + "50070";
          }
          if (roleValue == "BCPC-Hadoop-Head-Hive") {
            repoUrls["Hive Metastore - (" + currentMachine["machinename"] + ")"] = thriftBaseString + "9083"
            repoUrls["Hive Server2  - (" + currentMachine["machinename"] + ")"] = jdbcBaseString + "10000/default"
          }
          if (roleValue == "BCPC-Hadoop-Head-Hive-Ldap") {
            repoUrls["Hive Metastore - (" + currentMachine["machinename"] + ")"] = thriftBaseString + "9083"
            repoUrls["Hive Server2 LDAP - (" + currentMachine["machinename"] + ")"] = jdbcBaseString + "10000/default"
          }
        }

        match = reciperegex.exec(rolesrecipes[idx])
        if (match && match[1]) {
          currentMachine["recipes"].push(match[1]);
          continue;
        }
        currentMachine["others"].push(rolesrecipes[idx]);
      }


      // allClusterInfo[repo][parts[oo + 0]]["machinename"] = [parts[oo + 0]];
      // screen.append('<dt>' + this.url + '</a></dt>');

    });

    // screen.append('</dl>');
  }
};

var parseEnvironmentFile = function(data, repo) {
  console.log("Parsing environment file now");
  if (data.data.content && data.data.encoding === "base64") {
    var env = jQuery.parseJSON(window.atob(data.data.content));
    if (env && env.override_attributes) {
      if (env.override_attributes.bcpc && env.override_attributes.bcpc.bootstrap) {
        var bootstrap_ip = env.override_attributes.bcpc.bootstrap.server;
        if (bootstrap_ip) {
          allClusterInfo[repo]["bootstrap_ip"] = bootstrap_ip;
        }
      }
      if (env.override_attributes.bcpc && env.override_attributes.bcpc.management) {
        var mgmt = env.override_attributes.bcpc.management;
        //console.log( "MGMT [" + JSON.stringify( mgmt ) + "]" );
        if (mgmt.vip) {
          allClusterInfo[repo]["mgmt_vip"] = mgmt.vip;
        }
        var floating = env.override_attributes.bcpc.floating;
        if (floating.vip) {
          allClusterInfo[repo]["floating_vip"] = floating.vip;
          if (!allClusterInfo[repo]["urls"]) {
            allClusterInfo[repo]["urls"] = new Object();
          }
        }
        var name = env.name
        if (!allClusterInfo[repo]["urls"]) {
          allClusterInfo[repo]["urls"] = new Object();
        }
        allClusterInfo[repo]["urls"]["Graphite"] = "https://" + name.toLowerCase() + ".hadoop.bloomberg.com:8888";
        allClusterInfo[repo]["urls"]["Ooozie ($OOZIE_URL)"] = "https://" + name.toLowerCase() + ".bloomberg.com:11010";
        var vas = env.override_attributes.vas;
        allClusterInfo[repo]["domain"] = "Default DEV";
      }
      if (vas && vas.domain) {
        if (addevregex.test(vas.domain)) {
          allClusterInfo[repo]["domain"] = "DEV";
        } else if (adprdregex.test(vas.domain)) {
          allClusterInfo[repo]["domain"] = "PROD";
        } else {
          allClusterInfo[repo]["domain"] = vas.domain;
        }
      }
    }
  }
}

$.githubUser = function(callback) {
  var reposurl = formAccessUrlWithCallback(baseUrl + "users/" + username + "/repos");
  console.log("REPOSURL: " + reposurl);
  jQuery.getJSON(reposurl, callback);
}

$.getClusterInfo = function(repo, sha, callback) {
  var newUrl = formAccessUrl(baseUrl + "repos/" + username + "/" + repo + "/git/blobs/" + sha);
  console.log("CONTENTSURL: " + newUrl);
  $.ajax({
    type: "GET",
    url: newUrl,
    dataType: "jsonp",
    success: function(data) {
      callback(data, repo);
    }
  });
}

$.getSingleClusterDetails = function(currentRepo) {
  var baseClusterUrl = baseUrl + "repos/" + username + "/" + currentRepo + "/contents";
  var newUrl = formAccessUrl(baseClusterUrl + "/cluster.txt");
  console.log("SHAURL(cluster.txt): " + newUrl);
  $.ajax({
    type: "GET",
    url: newUrl,
    dataType: "jsonp",
    success: function(data) {
      //console.log( "GetTextSha" + data );
      $.getClusterInfo(currentRepo, data.data.sha, parseClusterFile);
    },
  });

  newUrl = formAccessUrl(baseClusterUrl + "/environments/" + currentRepo.toUpperCase() + ".json");
  console.log("SHAURL(env): " + newUrl);
  $.ajax({
    type: "GET",
    url: newUrl,
    dataType: "jsonp",
    success: function(data) {
      //console.log( "GetTextSha" + data );
      $.getClusterInfo(currentRepo, data.data.sha, parseEnvironmentFile);
    },
  });
}

var showLoadMessage = function(printStr) {
  $("#loading").empty().append(printStr).show();
  $("#allrepos").hide();
}

var hideLoadMessage = function() {
  $("#loading").hide();
}

var writeDataToScreen = function(data) {
  $("#allrepos").empty().append(data).show();
}

$.widget("custom.catcomplete", $.ui.autocomplete, {
  _create: function() {
    this._super();
    this.widget().menu("option", "items", "> :not(.ui-autocomplete-category)");
  },
  _renderMenu: function(ul, items) {
    var that = this,
        currentCategory = "";
    $.each(items, function(index, item) {
      var li;
      if (item.category != currentCategory) {
        ul.append("<li class='ui-autocomplete-category'>" + item.category + "</li>");
        currentCategory = item.category;
      }
      li = that._renderItemData(ul, item);
      if (item.category) {
        li.attr("aria-label", item.category + " : " + item.label);
      }
    });
  }
});

jQuery.fn.loadRepositories = function() {

  showLoadMessage("<br><br><span>Querying GitHub for " + username + "'s repositories...</span>");
  $.githubUser(function(dataarg) {
    //console.log(dataarg);
    // sortByNumberOfWatchers(repos);

    allClusterInfo = new Object();
    //console.log( "Empty: " + jQuery.isEmptyObject( allClusterInfo ) );
    //console.log( "CreatedAllClusterLength: " + Object.keys( allClusterInfo ).length );

    var countRepos = 0;
    var searchdata = [];
    var $singleUrl = $(dataarg.data);

    var devregex = /^D/;
    var betaregex = /BETA$/;
    $singleUrl.each(function() {
      if (limitRepos >= 0 && ++countRepos > limitRepos) {
        return;
      }
      if (decommissionedregex.test(this.description)) {
        //console.log( "MATCHED REGEX DECOMMISSION" );
        return;
      }

      var currentRepo = this.name;
      console.log("CurrentRepo: " + currentRepo);
      allClusterInfo[currentRepo] = new Object();
      allClusterInfo[currentRepo]["url"] = this.html_url;
      allClusterInfo[currentRepo]["description"] = this.description;
      allClusterInfo[currentRepo]["machines"] = new Object();

      //$.getSingleClusterDetails( currentRepo );
      var categoryStr = "PROD";
      var name = currentRepo.toUpperCase();
      if (devregex.test(name)) {
        categoryStr = "DEV";
      } else if (betaregex.test(name)) {
        categoryStr = "BETA";
      }

      searchdata.push({
        label: name,
        value: currentRepo,
        category: categoryStr
      });

    });

    searchdata.sort(
      function(a, b) {
        function reverse(s) {
          return s.split('').reverse().join('');
        }
        //console.log( "COMP[" + a.label + "][" + a.category + "]  [" + b.label + "][" + b.category + "]" );
        if (a.category == b.category) {
          if (a.label.length == b.label.length) {
            return (reverse(a.label).localeCompare(reverse(b.label)));
          } else {
            return (a.label.length - b.label.length);
          }
        } else {
          return (b.category.localeCompare(a.category));
        }
      });

    $("#search").catcomplete({
      delay: 0,
      source: searchdata,
      autoFocus: true,
      select: function(event, ui) {
        if (ui != null) {
          showLoadMessage("Retrieving data now...");
          console.log("UIITEM: " + JSON.stringify(ui.item));
          selectedRepos = [ui.item.value];
          $.getSingleClusterDetails(ui.item.value);
        }
      }
    });
    console.log("ALL DONE!");
  });

  $(document).ajaxStop(function() {
    hideLoadMessage();
    console.log("Triggered ajaxStop handler.");
    console.log("AllClusterLength: " + Object.keys(allClusterInfo).length);
    //console.log( "AllClusterInfoJSON: " + JSON.stringify( $( allClusterInfo ) ) );

    var tdata = '';
    console.log("NumReposToDisplay[" + selectedRepos.length + "]");
    //console.log( "AllClusterInfoRepos: " + JSON.stringify( allClusterInfo ) );
    /* Parse out object list and print to screen */
    for (var i = 0; i < selectedRepos.length; ++i) {
      var key = selectedRepos[i];
      console.log("AllClusterInfoSingleRepoName: " + key);
      var currentRepo = allClusterInfo[key];
      tdata += ('<div><dl>');
      tdata += ('<dt>Cluster: <b>' + key.toUpperCase() + '</b></dt>');
      tdata += ('<dt>Github Url: <a href="' + currentRepo["url"] + '">' + currentRepo["url"] + '</a></dt>');
      tdata += ('<dt>Description: ' + currentRepo["description"] + '</dt>');
      tdata += ('<br>');
      tdata += ('<dt>Virtual IP: ' + currentRepo["mgmt_vip"] + '</dt>');
      tdata += ('<dt>Bootstrap IP: ' + currentRepo["bootstrap_ip"] + '</dt>');
      tdata += ('<dt>Cluster Domain: ' + currentRepo["domain"] + '</dt>');
      tdata += ('<dt>Number of machines: ' + Object.keys(currentRepo["machines"]).length + '</dt>');

      var singleUrl = currentRepo["urls"];
      if (singleUrl && Object.keys(singleUrl).length > 0) {
        tdata += ('<br>');
        tdata += ('<dt><b><u>Important URLs</u></b></dt>');

        tdata += ('<div class="noouterborders"><table><tbody>');
        Object.keys(singleUrl).forEach(function(key) {
          tdata += ('<tr><td>' + key + '</td><td><a href="' + singleUrl[key] + '" target="_blank">' + singleUrl[key] + '</a></td></tr>');
        });
        tdata += ('</tbody></table>');
      }

      /* $tdata += ('<dd>' + currentRepo["description"] + '</dd>'); */
      tdata += ('</dl> ');


      var altclassheader = '"alt"';
      var header = '<div class="datagrid"><table><thead><tr>';
      if (decommissionedregex.test(currentRepo["description"])) {
        //console.log( "MATCHED REGEX DECOMMISSION" );
        header = '<div class="datagrid old"><table><thead><tr class="old">';
        altclassheader = '"alt old"';
      }

      tdata += (header);
      tdata += ('<th>Machine Name</th>');
      //tdata += ( '<th>Mac Address</th>');
      //tdata += ( '<th>IP Address</th>');
      tdata += ('<th>Roles</th>');
      tdata += ('<th>Recipes</th>');
      //tdata += ( '<th>Others</th>');
      // writeData += ('<th></th>');

      tdata += ('</tr></thead>');
      tdata += ('<tbody>');
      var singleMachine = currentRepo["machines"];
      if (singleMachine && Object.keys(singleMachine).length > 0) {
        var alt = false;
        Object.keys(singleMachine).forEach(function(key) {
          //console.log( "AllClusterInfoSingleRepoMachineName: " + key );
          var currentMachine = singleMachine[key];
          if (alt == false) {
            tdata += ('<tr>');
            alt = true;
          } else {
            tdata += ('<tr class=' + altclassheader + '>');
            alt = false;
          }

          tdata += ('<td>' + currentMachine["machinename"] + '</td>');
          //tdata += ('<td>' + currentMachine["macaddress"] + '</td>');
          //tdata += ('<td>' + currentMachine["ipaddress"] + '</td>');

          tdata += ('<td>' + currentMachine["roles"].join(", ") + '</td>');
          tdata += ('<td>' + currentMachine["recipes"].join(", ") + '</td>');
          //tdata += ('<td>' + currentMachine["others"].join( "\n" ) + '</td>');

          tdata += ('</tr>');
        });
      }
      tdata += ('</tbody></table></div></div><br><br>');
    };
    if (selectedRepos.length > 0) {
      //console.log( "TDATA:" + JSON.stringify( tdata ) );
    }

    writeDataToScreen(tdata);
    console.log("Wrote to screen. All Done.");
  });

  function sortByNumberOfWatchers(repos) {
    repos.sort(function(a, b) {
      return b.watchers - a.watchers;
    });
  }
}

window.onerror = function(msg, url, line, col, error) {

  // This tells jQuery no more ajax Requests are active
  // (this way Global start/stop is triggered again on next Request)
  jQuery.active = 0;

  // Now process the error
  hideLoadMessage();
  // Note that col & error are new to the HTML 5 spec and may not be
  // supported in every browser.  It worked for me in Chrome.
  var extra = !col ? '' : "<br>Column: " + col;
  extra += !error ? '' : "<br>Error: " + error;

  // You can view the information in an alert to see things working like this:
  var data = "Error: " + msg + "<br>Url: " + url + "<br>Line: " + line + extra;
  data = data + "<br><br>Please open a DRQS to group 1236 regarding this error";

  // TODO: Report this error via ajax so you can keep track
  //       of what pages have JS issues

  writeDataToScreen(data);

  // If you return true, then error alerts (like in older versions of
  // Internet Explorer) will be suppressed.
  return true;
}
